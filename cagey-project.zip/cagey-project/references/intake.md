# Intake reference

## Canonical message format

Every parser must emit a list of messages with at least these fields:

```json
{
  "id": 42,
  "speaker": "Alice Chen",
  "role": "peer",           // "boss", "peer", "report", "user", "unknown"
  "ts": "2026-03-12T14:22:00",
  "channel": "#eng-standup",
  "text": "sure, whatever works",
  "reply_to": 40,            // optional, thread parent id
  "reactions": ["thumbsup"], // optional
  "edited": false
}
```

If a field is missing from the source, omit it rather than fabricating. The aggregator tolerates missing `channel`, `reply_to`, `reactions`, `edited`.

## Slack exports

Slack's JSON export is a folder per channel, with one file per day named `YYYY-MM-DD.json`. Each file is a list of message objects. Key fields: `user`, `ts` (unix float), `text`, `thread_ts`, `reactions`, `subtype`. Skip `subtype == "bot_message"` unless the user says bots matter. Resolve user IDs via the top-level `users.json` file that ships with the export.

CSV exports (from third-party tools) vary wildly — sniff the header and map common names: `user|username|from|sender` → speaker, `timestamp|ts|time|date` → ts, `message|text|body` → text.

## Teams / WeChat / generic text

Common patterns to recognize:

- `Alice [09:14]: text` — bracketed time
- `Alice — 09:14` then text on next line — em-dash separator
- `[2026-03-12 14:22] Alice: text` — full timestamp
- `王雷 2026-03-12 14:22` — Chinese name + space-separated datetime
- WeChat exports often put each message on its own line with no timestamp between; use file modification time or ask the user for the date window.

When dates are missing, still score — just skip the time-series charts and note the limitation in the report.

## Screenshots

Screenshots are the messiest input. The OCR pipeline:

1. Run Tesseract on each image. If not installed: `apt-get install -y tesseract-ocr` inside the sandbox.
2. Post-process: merge wrapped lines, strip UI chrome ("Reply," "Edited," reaction counts).
3. Feed the cleaned text through `parse_generic.py`.
4. **Always show the user the extracted text before scoring.** OCR routinely mis-reads names and timestamps, and scoring a garbled name as a real person is worse than useless.

If there are more than ~10 screenshots, ask the user if they'd prefer to paste text directly.

## Confirmation prompts

Before Phase 2, confirm with the user:

1. "I found N messages from {list of speakers}. Which of these are bosses or managers?"
2. "Which name in this log is you? I'll treat your own messages as context only."
3. "What time window are you most interested in? (I'll still score everything, but the report will highlight that window.)"
4. "Any channels or DMs I should exclude?"

Keep it to one AskUserQuestion call with multiple sub-questions rather than several round trips.

## Edge cases

- **Edited messages**: score the final version, but note in evidence if the edit history is available and shows meaningful changes.
- **Deleted messages**: if Slack shows `[message deleted]`, flag the slot but don't score.
- **Emoji reactions**: count them as weak positive/negative signals. 🎉 and ❤️ add warmth; 👀 and 😬 add tension. See `rubric.md`.
- **Bots and automations**: exclude by default.
- **Non-English**: the rubric works across languages but the worked examples are English. For CJK languages, pay extra attention to honorifics and register shifts — they carry most of the subtext.
- **Tiny samples** (<20 messages): still produce all three deliverables, but cap confidence at 0.5 and say so in the report.
