# Dashboard reference

The HTML dashboard is the showpiece deliverable. It must be a single self-contained file that opens in any browser with no build step and no server.

## Structure

Top to bottom:

1. **Header** — "Cagey Project — [window]" + message/speaker/channel counts
2. **Risk flag strip** — any flags from Phase 5 as dismissible red/amber cards at the top
3. **Per-speaker cards** — one card per non-user speaker, showing: name + role chip, mean scores on the six dimensions as mini bar charts, a 7-point sparkline for warmth and frustration, and a "see messages" expand
4. **Time series** — line chart of each dimension, rolling 3-day average, one line per speaker, with a channel filter
5. **Tension heatmap** — rows = speakers, columns = weeks, cell color = (frustration + withdrawal − warmth), click a cell to see the messages behind it
6. **Top cagey messages table** — sortable by any dimension, filterable by speaker and channel, each row expandable to show evidence span and confidence
7. **Rubric footer** — collapsed accordion with the scoring definitions, so readers can audit

## Styling

Restrained, not cheerful. The subject matter is sensitive — a bright colorful "analytics" look feels wrong. Use:

- Deep ink background (#11131a) or warm paper background (#f8f5ee), user-togglable
- Serif display font for headers (Georgia / Cormorant)
- System sans for body
- Accent: amber #d4a24c for warmth, slate #6b7a8f for neutral, muted coral #c9685a for frustration (never bright red — it reads alarmist)
- Plenty of whitespace; do not cram

## Libraries

- Chart.js from cdnjs — inline script tag, no npm
- No frameworks, no build step — vanilla JS and one `<style>` block
- Embed the scored data as a JSON literal inside the HTML so the file is truly self-contained

## Interactivity

- Click a speaker card → filter the time series and message table to that speaker
- Click a week in the heatmap → filter the table to that week
- Sort table by any dimension
- Light/dark toggle
- No external data fetches, ever

## Do not

- Do not use localStorage or sessionStorage
- Do not auto-play anything
- Do not include real names in page titles or filenames written to disk — use "cagey_dashboard.html" and keep names inside the file
- Do not include diagnostic language or advice copy in the dashboard chrome
