# Risk flag patterns

Phase 5 scans the aggregated scores for these patterns. Each flag is observational — it names what's in the data, not what the user should do.

## Flag format

Every flag is a dict:

```json
{
  "name": "Sustained hostility pattern",
  "severity": "amber",      // "amber" or "red"
  "window": ["2026-03-10", "2026-03-14"],
  "people": ["Manager A → User"],
  "evidence": [
    {"ts": "...", "speaker": "...", "text": "...", "frustration": 4}
  ],
  "description": "Over 5 consecutive workdays, Manager A's messages directed at User scored frustration ≥3 in 8 of 11 exchanges."
}
```

Severity: **amber** for notable patterns, **red** only when the evidence is unambiguous and sustained. Err toward amber.

## The pattern library

### Sustained hostility

One speaker directs frustration ≥3 at another across ≥3 distinct days, with ≥60% of their messages to that target scoring above the speaker's own baseline.

### Exclusion signal

A participant's share of messages in an active channel drops by ≥50% relative to their prior 2-week baseline, while channel volume stays within 25% of normal. (Not a flag if the person is on PTO per context clues.)

### Panic spiral

Mean stress across all participants in a channel rises ≥1.5 points over a ≤48-hour window and does not recover within 24 hours.

### Psychological-safety erosion

Over a ≥2-week window, questions (messages ending with `?`), hedges ("I think," "maybe," "not sure"), and disagreements all drop by ≥40% relative to baseline, while message uniformity (measured as inverse variance in length) rises.

### Sudden warmth reversal

A speaker whose prior warmth baseline is ≥3 drops to ≤1 for ≥5 consecutive messages in the same channel, with no observable trigger in the log. Often the earliest flag worth raising.

### Lopsided emotional labor

One participant carries a disproportionate share of warmth and safety signals (≥2× the group mean) across ≥3 weeks. Not inherently bad, but worth surfacing.

### Night-and-weekend creep

Messages from a speaker shift meaningfully into off-hours (before 8am, after 8pm local, or weekends) relative to their baseline. Surface alongside stress scores.

## What NOT to flag

- Single bad days — everyone has them
- Isolated sharp messages without a pattern
- Cultural differences in register (directness ≠ hostility)
- The user's own messages (they can read themselves)
- Anything that would require inferring mental health status

## Tone of flag descriptions

Write flags the way a good auditor writes findings: name the pattern, cite the evidence, stop. No advice. No speculation about why. No adjectives like "toxic," "abusive," "worrying." If the pattern is serious enough that the user might need outside help, the report can include one neutral line pointing them to HR, a manager, a trusted peer, or a professional — but only once, and only at the end.
