# Subaudition Classification Rules

Use these keyword triggers, linguistic markers, and contextual patterns to classify messages.

---

## S1 — Directive

**Signals**: Commands, assignments, deadlines, ownership statements.

Keywords: `make sure`, `you need to`, `please do`, `handle this`, `send me`, `by EOD`, `ASAP`,
`I need`, `deadline`, `must`, `have to`, `your job`, `your responsibility`, `action item`

Patterns:
- Imperative sentence structure ("Do X by Y")
- Assigns tasks without asking ("You'll be taking care of...")
- Sets expectations without discussion

---

## S2 — Approving

**Signals**: Praise, validation, agreement, affirmation.

Keywords: `great work`, `love this`, `well done`, `exactly right`, `perfect`, `I agree`,
`good idea`, `brilliant`, `nicely done`, `you nailed it`, `this is solid`, `yes!`, `absolutely`

Patterns:
- Responds positively and promptly to others' contributions
- Uses complimentary adjectives unprompted
- Echoes and validates others' proposals

---

## S3 — Deflecting

**Signals**: Avoids ownership, passes blame, redirects responsibility.

Keywords: `that's not my`, `not my area`, `ask [someone else]`, `wasn't my decision`,
`I was told to`, `management said`, `that's on them`, `not sure who owns this`,
`wasn't involved`, `above my pay grade`, `check with`, `not my call`

Patterns:
- Redirects accountability to others
- Uses passive voice to obscure agency
- Responds to problems by pointing elsewhere

---

## S4 — Micromanaging

**Signals**: Excessive follow-up, over-specification, distrust in others' execution.

Keywords: `just checking`, `any updates?`, `where are we on`, `did you get a chance`,
`reminder`, `following up`, `let me know every step`, `make sure you`, `I need to approve`,
`don't proceed without`, `loop me in`, `keep me posted at every stage`

Patterns:
- Multiple follow-up messages on same topic within short time
- Detailed instructions that go beyond what's needed
- Requests frequent status updates unprompted

---

## S5 — Supportive

**Signals**: Offers help, emotional attunement, encouragement.

Keywords: `let me know if you need help`, `I can take that off your plate`,
`happy to assist`, `how are you holding up`, `no worries`, `take your time`,
`we've got this`, `I'm here`, `reach out anytime`, `you've got this`

Patterns:
- Volunteers assistance proactively
- Acknowledges others' stress or workload
- Uses warm, inclusive tone

---

## S6 — Passive-Aggressive

**Signals**: Indirect criticism, sarcasm, feigned politeness masking frustration.

Keywords: `as I mentioned`, `as per my last email`, `just to clarify again`,
`no worries, I'll just do it myself`, `interesting choice`, `sure, if that's what you want`,
`I guess`, `fine`, `noted` (when used dismissively), `obviously`, `clearly`

Patterns:
- Politeness markers followed by subtle jabs ("Thanks for finally...")
- Repeats previous information pointedly ("As I said before...")
- Volunteering to do something with resentful framing

---

## S7 — Analytical

**Signals**: Data-driven reasoning, structured thinking, questions assumptions.

Keywords: `what's the data say`, `according to`, `evidence`, `metrics`, `results show`,
`hypothesis`, `let me think through`, `the reason is`, `because`, `therefore`,
`what's the ROI`, `cost-benefit`, `breakdown`, `analysis`, `compared to`

Patterns:
- Asks "why" and "how" questions before acting
- Requests numbers or evidence before agreeing
- Proposes structured frameworks

---

## S8 — Political

**Signals**: Name-drops power, manages perception, aligns with authority.

Keywords: `the CEO said`, `leadership wants`, `I ran it by [senior person]`,
`make sure [VP] sees this`, `this aligns with [executive]'s vision`,
`we should loop in [director]`, `I want to make sure I'm visible on this`,
`credit to the team` (but only when convenient), `I mentioned this weeks ago`

Patterns:
- References senior stakeholders to legitimize own position
- Volunteers for high-visibility work
- Steers credit toward self in front of leadership

---

## S9 — Collaborative

**Signals**: Invites input, shares credit, uses collective language.

Keywords: `what does everyone think`, `team effort`, `we did this together`,
`your input matters`, `let's decide together`, `open to ideas`, `thoughts?`,
`building on what [name] said`, `I couldn't have done this without`, `our approach`

Patterns:
- Uses "we" and "us" rather than "I"
- Asks for opinions before deciding
- Credits others' contributions explicitly

---

## S10 — Disengaged

**Signals**: Minimal effort in responses, latency, vagueness, avoidance.

Keywords: `ok`, `sure`, `sounds good`, `k`, `yep`, `noted`, `will do` (minimal context),
`on it` (no follow-through), `got it` (repeated without action)

Patterns:
- Single-word or very short replies to complex questions
- Consistent pattern of vague acknowledgment without substance
- Long gaps between messages (if timestamps available)
- Does not ask clarifying questions even when needed

---

## Scoring Guidelines

- Assign **1 point** per message per matching subaudition.
- If a message strongly matches 2 categories, assign both.
- Compute **total score per subaudition per speaker** for the frequency matrix.
- A speaker's **dominant subaudition** is their highest-scoring category.
- Flag as **risk** if: S3 ≥ 3, S6 ≥ 2, S8 ≥ 3, or S10 ≥ 4 (relative to message volume).
