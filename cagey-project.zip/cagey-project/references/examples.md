# Worked mini-examples

Three short fully-worked analyses, to anchor the skill's judgment.

## Example A — "Is my boss mad at me?"

**Input** (5 messages over 2 days, pasted):

```
Mgr [Mon 09:02]: morning! did you get a chance to look at the doc?
User [Mon 09:40]: yes sorry just opened it now, thoughts coming shortly
Mgr [Mon 14:12]: any update?
Mgr [Tue 08:55]: I went ahead and made the changes myself.
Mgr [Tue 08:56]: let me know if you have concerns.
```

**Scoring highlights:**

- Mon 09:02 — stress 1, frustration 1, warmth 2. Label: "friendly nudge." Conf 0.7.
- Mon 14:12 — stress 2, frustration 2, warmth 0, withdrawal 1. Label: "impatient check-in." Conf 0.7.
- Tue 08:55 — stress 1, frustration 3, warmth 0, safety 2, withdrawal 2. Label: "cold takeover." Conf 0.75. Evidence: "'went ahead and made the changes myself' + period, after prior warm opener — escalation."
- Tue 08:56 — frustration 3, warmth 0. Label: "performative openness." Conf 0.6. Evidence: "'let me know if you have concerns' with no follow-up question mark."

**Flags:** amber — "sudden warmth reversal" between Mon 09:02 and Tue 08:55 (warmth 2 → 0, frustration 1 → 3).

**Report tone:** "The manager's messages on Tuesday morning scored lower on warmth and higher on frustration than the preceding messages. This is a two-day sample, so confidence is limited, but the shift from a warm opener to 'went ahead and made the changes myself' is the dominant signal."

## Example B — "Team vibe check on #eng-standup"

**Input:** Slack export, 3 weeks, ~400 messages, 6 participants.

**What the skill does:**

1. Parses the JSON, resolves user IDs.
2. Asks the user which participants are managers (1 of 6).
3. Scores all 400 messages. Per-speaker baselines are computed from week 1.
4. Aggregates: finds that participant "Sam" shows steady withdrawal rise (1 → 3) across the window, and that the manager's psychological-safety score drops in week 3 (3 → 1).
5. Flags amber: "exclusion signal — Sam's message share dropped from 18% to 6% between week 1 and week 3."
6. Flags amber: "psychological-safety erosion — question rate in #eng-standup dropped 55% in week 3."

**Dashboard highlights:** the tension heatmap shows a dark row on Sam and a darker column on week 3.

**Report tone:** Observational, not diagnostic. Names the patterns, quotes the evidence, stops.

## Example C — Screenshot of a single thread

**Input:** Three screenshots from a WeChat group chat, Chinese text.

**What the skill does:**

1. OCRs each screenshot, shows the extracted text to the user, asks them to correct two mis-read names.
2. Warns that confidence is capped at 0.5 for the whole analysis (small sample + OCR).
3. Scores the ~20 extracted messages. Pays extra attention to honorific shifts (e.g., 王老师 → 王总 is a register shift worth noting).
4. Produces the three deliverables but keeps the report short and leads with the sample-size caveat.
5. No risk flags — sample is too small to justify any.

**What the skill does not do:** extrapolate to "your team is dysfunctional" or "your boss dislikes you." Twenty OCR'd messages are not enough to say that, and the skill says so.
