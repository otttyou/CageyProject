# Cagey Project — References

## Files in This Directory

### `subaudition-rules.md`
Full keyword and linguistic pattern rules for classifying messages into the 10 subaudition
categories (S1–S10). Load this when performing classification to ensure accurate scoring.

### `README.md`
This file.

---

## Quick Pipeline Reference

```bash
# 1. Parse chat file
python scripts/parse_chats.py --input chats.txt --format auto --output parsed.json

# 2. Classify subauditions
python scripts/classify_subauditions.py --input parsed.json --output subaudition_matrix.csv

# 3. Generate visualizations
python scripts/visualize.py --matrix subaudition_matrix.csv --output-dir assets/

# 4. Run demo (no data needed)
python scripts/demo.py --output-dir demo_assets/
```

## Dependencies

```
pip install matplotlib numpy
```

## Output Files

| File | Description |
|---|---|
| `parsed.json` | Structured message records |
| `subaudition_matrix.csv` | Speaker × Subaudition frequency table |
| `classified_messages.json` | Per-message subaudition labels |
| `risk_flags.json` | Speakers exceeding risk thresholds |
| `assets/stacked_bar.png` | Stacked bar chart by speaker |
| `assets/heatmap.png` | Heatmap of subaudition frequencies |
| `assets/radar_chart.png` | Radar chart for top speaker |
| `assets/pie_chart.png` | Overall distribution pie chart |
