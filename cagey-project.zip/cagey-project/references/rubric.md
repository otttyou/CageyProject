# Scoring rubric

This is the heart of the skill. Read it carefully before scoring.

## The six dimensions

Each message gets a score on each dimension. Scores are integers 0–5 except morale drift, which is −5 to +5. Context matters — the same literal text can score very differently depending on what came before it and the speaker's own baseline.

### 1. Stress / pressure (0–5)

How much urgency, time pressure, or overload does the message convey? Look for: compressed deadlines, "asap," "just need," "real quick" (often ironic), fragmented syntax, ellipses, dropped punctuation, stacked messages in short succession.

- 0 — calm, measured
- 1–2 — mild time pressure or busyness
- 3 — clearly stressed but coping
- 4 — under strain, starting to leak through tone
- 5 — visibly overloaded or venting

**Examples:**
- "Can you take a look when you get a chance" → 1
- "need this by EOD" → 3
- "i have 4 things due today and now this" → 5

### 2. Frustration / suppressed anger (0–5)

The big one for boss-reading. Look for: curt replies after longer ones, pointed "thanks," "as I said earlier," "per my last message," full stops where emoji used to be, one-word answers, passive constructions ("it would be helpful if"), corrections phrased as questions ("are we sure about this approach?"), and the infamous "interesting."

- 0 — no friction
- 1 — mildly impatient
- 2 — polite-but-not-warm, noticeable stiffening
- 3 — clearly annoyed, still professional
- 4 — pointed, passive-aggressive, or cold
- 5 — open hostility or contempt

**Examples:**
- "got it thx!" after a warm thread → 1
- "as I mentioned in the doc, …" → 3
- "Interesting choice." → 4 (classic)

### 3. Warmth / connection (0–5)

Humor, personal check-ins, genuine appreciation, emoji that fit the room, shared references. This is not politeness — a stiffly polite "thank you so much for your help" can be warmth 1, while "lol ok" between friends can be warmth 3.

- 0 — purely transactional
- 1 — polite
- 2 — friendly
- 3 — warm, personal
- 4 — affectionate or playful
- 5 — genuinely close, shared vulnerability

### 4. Psychological safety (0–5)

Willingness of the speaker to be wrong, disagree, admit confusion, joke, push back. This dimension is about the *speaker*, not the room — it measures how safe *they* appear to feel.

- 0 — hyper-guarded, hedged, deferential to the point of erasure
- 1 — cautious
- 2 — neutral
- 3 — willing to ask questions, admit gaps
- 4 — comfortable disagreeing or pushing back
- 5 — openly dissents, jokes at own expense, brings half-baked ideas

### 5. Withdrawal / disengagement (0–5)

Shrinking message length, longer delays, flat affect, emoji disappearing, "k," "sure," "sounds good" without elaboration. Compare to the speaker's own baseline, not a universal norm — some people are naturally terse.

- 0 — fully present
- 3 — noticeably pulling back
- 5 — gone quiet, going through the motions

### 6. Morale drift (−5 to +5)

A *relative* score: how does this message compare to this speaker's baseline over the window? Positive = rising, negative = falling. Computed by comparing current rolling warmth + safety − withdrawal to the speaker's earlier rolling average. This one is typically assigned during aggregation rather than per-message scoring, but flag obvious single-message shifts inline.

## Dominant undercurrent label

Pick one short phrase that captures what the message feels like *underneath* the words. Good labels are specific and observable:

- "quiet resentment"
- "burned out but coping"
- "performing enthusiasm"
- "relieved"
- "testing the water"
- "shutting down"
- "fishing for reassurance"
- "cold dismissal"
- "genuine care"
- "nervous oversharing"

Avoid diagnostic language ("depressed," "narcissistic"). Avoid moralizing ("toxic," "unprofessional"). Stay observational.

## Confidence

Each score carries a confidence 0–1. Drop confidence when:

- The message is very short (<5 words) with no context
- The speaker has fewer than 5 messages in the window
- The reading hinges on tone markers the written medium obscures
- The surrounding messages contradict the reading
- OCR was involved and the text is suspect

Confidence < 0.4 means the reading is a guess. Flag low-confidence readings in the report and suggest the user eyeball them.

## Evidence spans

Always attach the *specific words* that drove each score. "Bare 'ok.' after three paragraphs of warmth" is a good evidence note; "vibe is off" is not.

## Worked examples

### Example 1

Context: Alice has been sending 2–3 sentence replies with emoji all week. Today:

> Alice: ok.

Scores: stress 2, frustration 3, warmth 0, safety 1, withdrawal 4. Label: "sudden cold." Confidence: 0.7. Evidence: "single-word reply after sustained multi-sentence warm baseline."

### Example 2

Context: First message in the thread.

> Manager: Interesting approach. Let's sync tomorrow.

Scores: stress 1, frustration 3, warmth 1, safety 2, withdrawal 1. Label: "polite disagreement incoming." Confidence: 0.55 (first-message, limited context). Evidence: "'Interesting' + deferred sync is a common soft-pushback pattern, but without prior baseline it could also be neutral."

### Example 3

> Bob: lol yeah no idea, i'll poke around and report back 🙃

Scores: stress 2, frustration 0, warmth 3, safety 4, withdrawal 0. Label: "comfortable not knowing." Confidence: 0.8. Evidence: "open admission of uncertainty, playful emoji, volunteering follow-up — classic psychological-safety signal."
