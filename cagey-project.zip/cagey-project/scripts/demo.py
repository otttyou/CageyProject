#!/usr/bin/env python3
"""
demo.py — Cagey Project
Generate a sample chat dataset and run the full pipeline end-to-end.
Used for testing and demonstration purposes.

Usage:
    python demo.py --output-dir assets/
"""

import json
import os
import argparse
import subprocess
import sys

SAMPLE_CHATS = """Boss: Make sure the report is on my desk by EOD today.
Alice: Sure.
Bob: I'll take care of it — do you need the appendix included as well?
Boss: Yes, and loop in the director when you send it. Leadership wants visibility.
Alice: Ok.
Bob: What does everyone think about the new format? I'm open to ideas.
Boss: Just checking — any updates on the report?
Alice: on it.
Bob: I analyzed the data and the numbers suggest we need a different approach.
Boss: That's not my area — check with the finance team.
Alice: noted.
Bob: Building on what Alice said, let's decide together as a team.
Boss: Obviously the deadline hasn't changed. As I mentioned earlier, EOD means EOD.
Alice: got it.
Bob: I couldn't have done this without the team's help. Great work, everyone!
Boss: Make sure your name isn't on this — it was a team effort (wink).
Alice: yep.
Bob: According to the metrics, conversion dropped 12%. We need to investigate.
Boss: The CEO mentioned this is a priority, so don't proceed without my sign-off.
Alice: k.
Bob: Let me know if you need any help pulling the data — happy to assist.
Boss: Following up again. Where are we on the deliverable?
"""


def main():
    parser = argparse.ArgumentParser(description="Demo pipeline for Cagey Project")
    parser.add_argument("--output-dir", default="demo_assets")
    args = parser.parse_args()

    os.makedirs(args.output_dir, exist_ok=True)

    # Step 1: Write sample chat file
    chat_file = os.path.join(args.output_dir, "sample_chat.txt")
    with open(chat_file, 'w') as f:
        f.write(SAMPLE_CHATS)
    print(f"Sample chat written to {chat_file}")

    scripts = os.path.dirname(os.path.abspath(__file__))
    parsed = os.path.join(args.output_dir, "parsed.json")
    matrix = os.path.join(args.output_dir, "subaudition_matrix.csv")

    # Step 2: Parse
    subprocess.run([sys.executable, os.path.join(scripts, "parse_chats.py"),
                    "--input", chat_file, "--format", "plain", "--output", parsed], check=True)

    # Step 3: Classify
    subprocess.run([sys.executable, os.path.join(scripts, "classify_subauditions.py"),
                    "--input", parsed, "--output", matrix,
                    "--log", os.path.join(args.output_dir, "classified.json"),
                    "--risks", os.path.join(args.output_dir, "risks.json")], check=True)

    # Step 4: Visualize
    subprocess.run([sys.executable, os.path.join(scripts, "visualize.py"),
                    "--matrix", matrix, "--output-dir", args.output_dir], check=True)

    print(f"\nDemo complete. Charts saved to: {args.output_dir}/")


if __name__ == "__main__":
    main()
