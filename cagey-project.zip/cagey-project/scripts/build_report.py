#!/usr/bin/env python3
"""Build static PNG charts + a markdown report from rollups.json + scored.json.

Usage:
  python build_report.py scored.json rollups.json [--flags flags.json] --outdir out/
"""
import argparse, json, os
from datetime import datetime

DIMS = ['stress', 'frustration', 'warmth', 'safety', 'withdrawal']


def make_charts(rollups, outdir):
    try:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
    except ImportError:
        print("matplotlib not installed; skipping charts")
        return []
    os.makedirs(os.path.join(outdir, 'charts'), exist_ok=True)
    charts = []

    # Per-speaker bar chart
    speakers = list(rollups['by_speaker'].keys())
    if speakers:
        fig, ax = plt.subplots(figsize=(9, 0.6 * len(speakers) + 1.5))
        for i, d in enumerate(DIMS):
            vals = [rollups['by_speaker'][s]['means'][d] for s in speakers]
            ax.barh([s + '  ' * i for s in speakers], vals, label=d, height=0.15,
                    alpha=0.85)
        ax.set_xlim(0, 5)
        ax.set_title('Mean dimension scores by speaker')
        ax.legend(fontsize=8, loc='lower right')
        plt.tight_layout()
        p = os.path.join(outdir, 'charts', 'by_speaker.png')
        plt.savefig(p, dpi=140)
        plt.close()
        charts.append(p)

    # Time series
    weeks = sorted(rollups['by_week'].keys())
    if weeks:
        fig, ax = plt.subplots(figsize=(9, 4))
        for d in DIMS:
            ax.plot(weeks, [rollups['by_week'][w]['means'][d] for w in weeks],
                    marker='o', label=d)
        ax.set_ylim(0, 5)
        ax.set_title('Dimensions over time')
        ax.legend(fontsize=8)
        plt.xticks(rotation=45, ha='right')
        plt.tight_layout()
        p = os.path.join(outdir, 'charts', 'by_week.png')
        plt.savefig(p, dpi=140)
        plt.close()
        charts.append(p)

    return charts


def make_report(scored, rollups, flags, charts, outdir):
    lines = ['# Cagey Project — Analysis Report', '']
    lines.append(f"*Generated {datetime.now().strftime('%Y-%m-%d %H:%M')}*")
    lines.append('')
    lines.append('## Executive summary')
    w = rollups['window']
    lines.append(f"- Window: {w.get('start') or '?'} → {w.get('end') or '?'}")
    lines.append(f"- Messages scored: {rollups['total_messages']}")
    lines.append(f"- Speakers: {len(rollups['speakers'])}")
    lines.append(f"- Risk flags raised: {len(flags)}")
    lines.append('')
    lines.append('> All readings below are interpretations of tone, not claims about intent or state of mind. Confidence scores indicate how much context supported each reading.')
    lines.append('')

    if charts:
        lines.append('## Charts')
        for c in charts:
            rel = os.path.relpath(c, outdir)
            lines.append(f'![{os.path.basename(c)}]({rel})')
        lines.append('')

    lines.append('## Per speaker')
    for name, info in rollups['by_speaker'].items():
        drift = rollups['morale_drift'].get(name, 0)
        lines.append(f"### {name}")
        lines.append(f"*{info['count']} messages · mean confidence {info['mean_confidence']:.2f} · morale drift {drift:+.2f}*")
        lines.append('')
        for d in DIMS:
            lines.append(f"- **{d}**: {info['means'][d]:.2f}")
        lines.append('')

    lines.append('## Top cagey messages')
    lines.append('')
    lines.append('| when | who | text | cagey | conf | label |')
    lines.append('|---|---|---|---|---|---|')
    for m in rollups['top_cagey'][:15]:
        text = (m.get('text') or '').replace('|', '\\|')[:100]
        lines.append(f"| {(m.get('ts') or '')[:16]} | {m.get('speaker')} | {text} | {m.get('cageyness', 0):.1f} | {m.get('confidence', 0):.2f} | {m.get('label','')} |")
    lines.append('')

    if flags:
        lines.append('## Risk flags')
        for f in flags:
            lines.append(f"### {f['name']} ({f.get('severity','amber')})")
            lines.append(f["description"])
            lines.append('')
    else:
        lines.append('## Risk flags')
        lines.append('No patterns met the flag thresholds in this window.')
        lines.append('')

    lines.append('---')
    lines.append('*This report observes patterns in written communication. It is not a diagnosis, performance review, or basis for disciplinary action. If any of the patterns here feel serious, consider talking with a trusted peer, manager, HR, or a professional.*')

    with open(os.path.join(outdir, 'cagey_report.md'), 'w', encoding='utf-8') as f:
        f.write('\n'.join(lines))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('scored_json')
    ap.add_argument('rollups_json')
    ap.add_argument('--flags', default=None)
    ap.add_argument('--outdir', default='.')
    args = ap.parse_args()
    os.makedirs(args.outdir, exist_ok=True)
    scored = json.load(open(args.scored_json, encoding='utf-8'))
    rollups = json.load(open(args.rollups_json, encoding='utf-8'))
    flags = json.load(open(args.flags, encoding='utf-8')) if args.flags else []
    charts = make_charts(rollups, args.outdir)
    make_report(scored, rollups, flags, charts, args.outdir)
    print(f"Wrote report to {args.outdir}/cagey_report.md")


if __name__ == '__main__':
    main()
