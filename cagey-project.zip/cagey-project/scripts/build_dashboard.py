#!/usr/bin/env python3
"""Build a self-contained HTML dashboard from scored.json + rollups.json.

Usage:
  python build_dashboard.py scored.json rollups.json [--flags flags.json] -o cagey_dashboard.html
"""
import argparse, json, html

TEMPLATE = r"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Cagey Project — Dashboard</title>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js"></script>
<style>
  :root {
    --bg: #11131a; --panel: #1a1d27; --ink: #f1ece0; --muted: #8a8f9e;
    --amber: #d4a24c; --slate: #6b7a8f; --coral: #c9685a; --border: #2a2e3a;
  }
  body.light { --bg: #f8f5ee; --panel: #ffffff; --ink: #1a1a1a; --muted: #6b6b6b; --border: #e3ddd1; }
  * { box-sizing: border-box; }
  body { margin: 0; background: var(--bg); color: var(--ink); font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; }
  h1, h2, h3 { font-family: Georgia, "Cormorant Garamond", serif; font-weight: 400; letter-spacing: 0.01em; }
  h1 { font-size: 2.4rem; margin: 0 0 0.3rem 0; }
  h2 { font-size: 1.5rem; margin: 2.5rem 0 1rem 0; border-bottom: 1px solid var(--border); padding-bottom: 0.5rem; }
  .wrap { max-width: 1200px; margin: 0 auto; padding: 3rem 2rem; }
  .meta { color: var(--muted); margin-bottom: 2rem; }
  .toggle { float: right; background: none; color: var(--muted); border: 1px solid var(--border); padding: 0.4rem 0.8rem; cursor: pointer; font-family: inherit; }
  .flag { background: var(--panel); border-left: 3px solid var(--amber); padding: 1rem 1.3rem; margin-bottom: 0.8rem; }
  .flag.red { border-left-color: var(--coral); }
  .flag-name { font-weight: 600; margin-bottom: 0.3rem; }
  .flag-desc { color: var(--muted); font-size: 0.95rem; }
  .grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 1rem; }
  .card { background: var(--panel); border: 1px solid var(--border); padding: 1.2rem; }
  .card-name { font-family: Georgia, serif; font-size: 1.2rem; }
  .role { font-size: 0.75rem; color: var(--muted); text-transform: uppercase; letter-spacing: 0.08em; margin-left: 0.5rem; }
  .dim-row { display: flex; align-items: center; gap: 0.5rem; margin: 0.3rem 0; font-size: 0.85rem; }
  .dim-label { width: 90px; color: var(--muted); }
  .dim-bar { flex: 1; height: 8px; background: var(--border); position: relative; }
  .dim-fill { height: 100%; background: var(--slate); }
  .dim-fill.frustration { background: var(--coral); }
  .dim-fill.warmth { background: var(--amber); }
  .dim-val { width: 30px; text-align: right; color: var(--muted); font-size: 0.8rem; }
  table { width: 100%; border-collapse: collapse; font-size: 0.9rem; }
  th, td { padding: 0.6rem 0.4rem; border-bottom: 1px solid var(--border); text-align: left; }
  th { color: var(--muted); font-weight: 500; font-size: 0.8rem; text-transform: uppercase; letter-spacing: 0.05em; cursor: pointer; }
  tr.message-row { cursor: pointer; }
  tr.message-row:hover { background: var(--panel); }
  .evidence { color: var(--muted); font-size: 0.85rem; padding: 0.5rem 0.8rem; font-style: italic; }
  canvas { max-width: 100%; }
  .chart-box { background: var(--panel); padding: 1.5rem; border: 1px solid var(--border); margin-bottom: 1rem; }
  details.rubric { background: var(--panel); padding: 1rem 1.3rem; margin-top: 3rem; border: 1px solid var(--border); }
  summary { cursor: pointer; color: var(--muted); }
</style>
</head>
<body>
<div class="wrap">
  <button class="toggle" onclick="document.body.classList.toggle('light')">Light / dark</button>
  <h1>Cagey Project</h1>
  <div class="meta" id="meta"></div>

  <h2>Risk flags</h2>
  <div id="flags"></div>

  <h2>Per speaker</h2>
  <div class="grid" id="speakers"></div>

  <h2>Time series</h2>
  <div class="chart-box"><canvas id="timeChart" height="100"></canvas></div>

  <h2>Top cagey messages</h2>
  <table id="msgTable">
    <thead><tr>
      <th data-sort="ts">when</th>
      <th data-sort="speaker">who</th>
      <th>text</th>
      <th data-sort="cageyness">cagey</th>
      <th data-sort="confidence">conf</th>
    </tr></thead>
    <tbody></tbody>
  </table>

  <details class="rubric">
    <summary>Scoring rubric (audit)</summary>
    <p><b>Stress</b> 0–5 · urgency, overload. <b>Frustration</b> 0–5 · curtness, pointed politeness.
    <b>Warmth</b> 0–5 · humor, personal care. <b>Safety</b> 0–5 · willingness to disagree or not-know.
    <b>Withdrawal</b> 0–5 · shrinking, flat affect. Cagey-ness = weighted intensity × confidence.
    Every reading is an interpretation, not a fact.</p>
  </details>
</div>

<script>
const DATA = __DATA__;
const ROLLUPS = __ROLLUPS__;
const FLAGS = __FLAGS__;
const DIMS = ["stress","frustration","warmth","safety","withdrawal"];

document.getElementById('meta').textContent =
  `${ROLLUPS.total_messages} messages · ${ROLLUPS.speakers.length} speakers · ${ROLLUPS.window.start || '?'} → ${ROLLUPS.window.end || '?'}`;

// Flags
const flagsEl = document.getElementById('flags');
if (!FLAGS.length) {
  flagsEl.innerHTML = '<div class="meta">No risk patterns flagged.</div>';
} else {
  FLAGS.forEach(f => {
    const d = document.createElement('div');
    d.className = 'flag ' + (f.severity || 'amber');
    d.innerHTML = `<div class="flag-name">${f.name}</div><div class="flag-desc">${f.description || ''}</div>`;
    flagsEl.appendChild(d);
  });
}

// Speaker cards
const speakersEl = document.getElementById('speakers');
Object.entries(ROLLUPS.by_speaker).forEach(([name, info]) => {
  const sample = DATA.find(m => m.speaker === name) || {};
  const role = sample.role || 'unknown';
  const card = document.createElement('div');
  card.className = 'card';
  const rows = DIMS.map(d => {
    const v = info.means[d] || 0;
    return `<div class="dim-row"><span class="dim-label">${d}</span>
      <div class="dim-bar"><div class="dim-fill ${d}" style="width:${v*20}%"></div></div>
      <span class="dim-val">${v.toFixed(1)}</span></div>`;
  }).join('');
  const drift = ROLLUPS.morale_drift[name] || 0;
  const driftStr = drift > 0 ? `+${drift}` : `${drift}`;
  card.innerHTML = `<div class="card-name">${name}<span class="role">${role}</span></div>
    <div class="meta" style="margin:0.3rem 0 0.8rem;font-size:0.8rem;">${info.count} msgs · drift ${driftStr}</div>
    ${rows}`;
  speakersEl.appendChild(card);
});

// Time chart
const weeks = Object.keys(ROLLUPS.by_week).sort();
const ctx = document.getElementById('timeChart').getContext('2d');
const palette = { stress:'#8a8f9e', frustration:'#c9685a', warmth:'#d4a24c', safety:'#6b7a8f', withdrawal:'#5c5f6e' };
new Chart(ctx, {
  type: 'line',
  data: {
    labels: weeks,
    datasets: DIMS.map(d => ({
      label: d,
      data: weeks.map(w => ROLLUPS.by_week[w].means[d] || 0),
      borderColor: palette[d],
      backgroundColor: palette[d],
      tension: 0.3,
      fill: false,
    })),
  },
  options: {
    responsive: true,
    scales: { y: { min: 0, max: 5, ticks: { color: '#8a8f9e' } }, x: { ticks: { color: '#8a8f9e' } } },
    plugins: { legend: { labels: { color: '#8a8f9e' } } },
  },
});

// Table
const tbody = document.querySelector('#msgTable tbody');
ROLLUPS.top_cagey.forEach(m => {
  const tr = document.createElement('tr');
  tr.className = 'message-row';
  tr.innerHTML = `<td>${(m.ts || '').slice(0,16)}</td>
    <td>${m.speaker}</td>
    <td>${(m.text || '').slice(0, 160)}</td>
    <td>${(m.cageyness || 0).toFixed(1)}</td>
    <td>${(m.confidence || 0).toFixed(2)}</td>`;
  tbody.appendChild(tr);
  const er = document.createElement('tr');
  er.style.display = 'none';
  er.innerHTML = `<td colspan="5" class="evidence"><b>${m.label || ''}</b> — ${m.evidence || ''}</td>`;
  tbody.appendChild(er);
  tr.addEventListener('click', () => { er.style.display = er.style.display === 'none' ? '' : 'none'; });
});
</script>
</body>
</html>
"""


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('scored_json')
    ap.add_argument('rollups_json')
    ap.add_argument('--flags', default=None)
    ap.add_argument('-o', '--output', default='cagey_dashboard.html')
    args = ap.parse_args()

    data = json.load(open(args.scored_json, encoding='utf-8'))
    roll = json.load(open(args.rollups_json, encoding='utf-8'))
    flags = json.load(open(args.flags, encoding='utf-8')) if args.flags else []

    out = (TEMPLATE
        .replace('__DATA__', json.dumps(data, ensure_ascii=False))
        .replace('__ROLLUPS__', json.dumps(roll, ensure_ascii=False))
        .replace('__FLAGS__', json.dumps(flags, ensure_ascii=False)))
    with open(args.output, 'w', encoding='utf-8') as f:
        f.write(out)
    print(f"Wrote {args.output}")


if __name__ == '__main__':
    main()
