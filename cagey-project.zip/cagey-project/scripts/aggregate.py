#!/usr/bin/env python3
"""Aggregate scored messages into per-speaker, per-week, per-channel rollups.

Input: scored.json (list of messages with scores dict)
Output: rollups.json

Each scored message should look like:
{
  "id": 1, "speaker": "...", "role": "...", "ts": "2026-03-12T14:22:00",
  "channel": "...", "text": "...",
  "scores": {"stress": 2, "frustration": 3, "warmth": 0, "safety": 1, "withdrawal": 4},
  "label": "sudden cold",
  "confidence": 0.7,
  "evidence": "single-word reply after warm baseline"
}
"""
import argparse, json, statistics
from collections import defaultdict
from datetime import datetime

DIMS = ['stress', 'frustration', 'warmth', 'safety', 'withdrawal']


def week_key(ts):
    if not ts:
        return 'unknown'
    try:
        dt = datetime.fromisoformat(ts)
    except Exception:
        return 'unknown'
    iso = dt.isocalendar()
    return f"{iso.year}-W{iso.week:02d}"


def mean(xs):
    return round(statistics.fmean(xs), 2) if xs else 0


def aggregate(messages):
    by_speaker = defaultdict(list)
    by_week = defaultdict(list)
    by_channel = defaultdict(list)

    for m in messages:
        if 'scores' not in m:
            continue
        by_speaker[m.get('speaker', 'unknown')].append(m)
        by_week[week_key(m.get('ts'))].append(m)
        by_channel[m.get('channel') or 'unknown'].append(m)

    def rollup(group):
        out = {}
        for k, msgs in group.items():
            out[k] = {
                'count': len(msgs),
                'means': {d: mean([x['scores'].get(d, 0) for x in msgs]) for d in DIMS},
                'mean_confidence': mean([x.get('confidence', 0.5) for x in msgs]),
            }
        return out

    # Cagey-ness score per message = weighted subtext intensity
    def cageyness(m):
        s = m['scores']
        return (s.get('frustration', 0) * 1.3 +
                s.get('withdrawal', 0) * 1.1 +
                s.get('stress', 0) * 0.8 -
                s.get('warmth', 0) * 0.6 -
                s.get('safety', 0) * 0.4) * m.get('confidence', 0.5)

    for m in messages:
        if 'scores' in m:
            m['cageyness'] = round(cageyness(m), 2)

    top_cagey = sorted(
        [m for m in messages if 'scores' in m],
        key=lambda m: m['cageyness'],
        reverse=True,
    )[:25]

    # Morale drift per speaker: compare second-half rolling mean to first-half
    drift = {}
    for sp, msgs in by_speaker.items():
        if len(msgs) < 4:
            drift[sp] = 0
            continue
        msgs_sorted = sorted(msgs, key=lambda m: m.get('ts') or '')
        half = len(msgs_sorted) // 2
        def score(bunch):
            return (mean([x['scores'].get('warmth', 0) for x in bunch]) +
                    mean([x['scores'].get('safety', 0) for x in bunch]) -
                    mean([x['scores'].get('withdrawal', 0) for x in bunch]))
        drift[sp] = round(score(msgs_sorted[half:]) - score(msgs_sorted[:half]), 2)

    return {
        'by_speaker': rollup(by_speaker),
        'by_week': rollup(by_week),
        'by_channel': rollup(by_channel),
        'top_cagey': top_cagey,
        'morale_drift': drift,
        'total_messages': len([m for m in messages if 'scores' in m]),
        'speakers': sorted(by_speaker.keys()),
        'window': {
            'start': min((m.get('ts') for m in messages if m.get('ts')), default=None),
            'end': max((m.get('ts') for m in messages if m.get('ts')), default=None),
        },
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('scored_json')
    ap.add_argument('-o', '--output', default='rollups.json')
    args = ap.parse_args()
    with open(args.scored_json, 'r', encoding='utf-8') as f:
        messages = json.load(f)
    roll = aggregate(messages)
    # also write back scored.json with cageyness attached
    with open(args.scored_json, 'w', encoding='utf-8') as f:
        json.dump(messages, f, indent=2, ensure_ascii=False)
    with open(args.output, 'w', encoding='utf-8') as f:
        json.dump(roll, f, indent=2, ensure_ascii=False)
    print(f"Wrote rollups to {args.output} — {roll['total_messages']} messages, {len(roll['speakers'])} speakers")


if __name__ == '__main__':
    main()
