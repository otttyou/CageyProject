#!/usr/bin/env python3
"""Build cagey_scores.xlsx from scored.json + rollups.json.

Requires openpyxl: pip install openpyxl --break-system-packages

Usage:
  python build_workbook.py scored.json rollups.json [--flags flags.json] -o cagey_scores.xlsx
"""
import argparse, json

DIMS = ['stress', 'frustration', 'warmth', 'safety', 'withdrawal']


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('scored_json')
    ap.add_argument('rollups_json')
    ap.add_argument('--flags', default=None)
    ap.add_argument('-o', '--output', default='cagey_scores.xlsx')
    args = ap.parse_args()

    try:
        from openpyxl import Workbook
        from openpyxl.styles import Font, PatternFill, Alignment
        from openpyxl.formatting.rule import ColorScaleRule
        from openpyxl.utils import get_column_letter
    except ImportError:
        print("openpyxl not installed. pip install openpyxl --break-system-packages")
        return

    scored = json.load(open(args.scored_json, encoding='utf-8'))
    rollups = json.load(open(args.rollups_json, encoding='utf-8'))
    flags = json.load(open(args.flags, encoding='utf-8')) if args.flags else []

    wb = Workbook()

    # Messages sheet
    ws = wb.active
    ws.title = 'Messages'
    headers = ['id', 'ts', 'speaker', 'role', 'channel', 'text'] + DIMS + ['cageyness', 'confidence', 'label', 'evidence']
    ws.append(headers)
    for c in ws[1]:
        c.font = Font(bold=True)
    for m in scored:
        s = m.get('scores', {})
        ws.append([
            m.get('id'), m.get('ts'), m.get('speaker'), m.get('role'),
            m.get('channel'), (m.get('text') or '')[:500],
            s.get('stress'), s.get('frustration'), s.get('warmth'),
            s.get('safety'), s.get('withdrawal'),
            m.get('cageyness'), m.get('confidence'),
            m.get('label'), m.get('evidence'),
        ])
    # Conditional formatting on dimension columns
    for idx, d in enumerate(DIMS, start=7):
        col = get_column_letter(idx)
        rng = f"{col}2:{col}{ws.max_row}"
        if d in ('warmth', 'safety'):
            ws.conditional_formatting.add(rng,
                ColorScaleRule(start_type='num', start_value=0, start_color='ffffff',
                               end_type='num', end_value=5, end_color='d4a24c'))
        else:
            ws.conditional_formatting.add(rng,
                ColorScaleRule(start_type='num', start_value=0, start_color='ffffff',
                               end_type='num', end_value=5, end_color='c9685a'))
    ws.column_dimensions['F'].width = 60

    # By Speaker
    ws2 = wb.create_sheet('By Speaker')
    ws2.append(['speaker', 'count', 'mean_confidence', 'morale_drift'] + DIMS)
    for c in ws2[1]:
        c.font = Font(bold=True)
    for name, info in rollups['by_speaker'].items():
        ws2.append([name, info['count'], info['mean_confidence'],
                    rollups['morale_drift'].get(name, 0)] +
                   [info['means'][d] for d in DIMS])

    # By Week
    ws3 = wb.create_sheet('By Week')
    ws3.append(['week', 'count'] + DIMS)
    for c in ws3[1]:
        c.font = Font(bold=True)
    for w in sorted(rollups['by_week'].keys()):
        info = rollups['by_week'][w]
        ws3.append([w, info['count']] + [info['means'][d] for d in DIMS])

    # Top Cagey
    ws4 = wb.create_sheet('Top Cagey')
    ws4.append(['ts', 'speaker', 'text', 'cageyness', 'confidence', 'label', 'evidence'])
    for c in ws4[1]:
        c.font = Font(bold=True)
    for m in rollups['top_cagey']:
        ws4.append([m.get('ts'), m.get('speaker'), (m.get('text') or '')[:300],
                    m.get('cageyness'), m.get('confidence'),
                    m.get('label'), m.get('evidence')])
    ws4.column_dimensions['C'].width = 60

    # Risk Flags
    ws5 = wb.create_sheet('Risk Flags')
    ws5.append(['name', 'severity', 'window', 'people', 'description'])
    for c in ws5[1]:
        c.font = Font(bold=True)
    for f in flags:
        ws5.append([
            f.get('name'), f.get('severity', 'amber'),
            ' → '.join(f.get('window', []) or []),
            ', '.join(f.get('people', []) or []),
            f.get('description', ''),
        ])
    ws5.column_dimensions['E'].width = 80

    # Rubric
    ws6 = wb.create_sheet('Rubric')
    ws6.append(['dimension', 'range', 'meaning'])
    for c in ws6[1]:
        c.font = Font(bold=True)
    rubric = [
        ('stress', '0-5', 'urgency, overload, time pressure'),
        ('frustration', '0-5', 'curtness, pointed politeness, passive aggression'),
        ('warmth', '0-5', 'humor, care, connection, genuine appreciation'),
        ('safety', '0-5', 'willingness to disagree, admit not-knowing, joke'),
        ('withdrawal', '0-5', 'shrinking responses, flat affect, going quiet'),
        ('morale_drift', '-5 to +5', 'second-half vs first-half shift per speaker'),
        ('cageyness', 'weighted', 'frustration + withdrawal + stress - warmth - safety, × confidence'),
        ('confidence', '0-1', 'how much context supported the reading'),
    ]
    for r in rubric:
        ws6.append(r)
    ws6.column_dimensions['C'].width = 70

    wb.save(args.output)
    print(f"Wrote {args.output}")


if __name__ == '__main__':
    main()
