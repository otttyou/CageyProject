#!/usr/bin/env python3
"""
classify_subauditions.py — Cagey Project
Classify each message into subaudition categories and build a frequency matrix.

Usage:
    python classify_subauditions.py --input parsed.json --output matrix.csv
"""

import argparse
import json
import csv
from collections import defaultdict

# ---------------------------------------------------------------------------
# Subaudition keyword/pattern rules
# ---------------------------------------------------------------------------
SUBAUDITIONS = {
    "S1_Directive": [
        "make sure", "you need to", "please do", "handle this", "send me",
        "by eod", "asap", "i need", "deadline", "must", "have to",
        "your job", "your responsibility", "action item", "ensure that",
        "complete this", "finish this", "deliver"
    ],
    "S2_Approving": [
        "great work", "love this", "well done", "exactly right", "perfect",
        "i agree", "good idea", "brilliant", "nicely done", "you nailed it",
        "this is solid", "yes!", "absolutely", "excellent", "fantastic",
        "well said", "spot on", "impressed"
    ],
    "S3_Deflecting": [
        "that's not my", "not my area", "ask ", "wasn't my decision",
        "i was told to", "management said", "that's on them",
        "not sure who owns this", "wasn't involved", "above my pay grade",
        "check with", "not my call", "not responsible", "someone else"
    ],
    "S4_Micromanaging": [
        "just checking", "any updates", "where are we on", "did you get a chance",
        "reminder:", "following up", "loop me in", "keep me posted",
        "don't proceed without", "i need to approve", "let me know every",
        "make sure you", "status update", "progress on"
    ],
    "S5_Supportive": [
        "let me know if you need", "happy to assist", "how are you holding up",
        "no worries", "take your time", "we've got this", "i'm here",
        "reach out anytime", "you've got this", "i can help",
        "i can take that", "off your plate", "support you"
    ],
    "S6_Passive_Aggressive": [
        "as i mentioned", "as per my last", "just to clarify again",
        "i'll just do it myself", "interesting choice", "if that's what you want",
        "i guess", "noted.", "obviously", "clearly", "per my previous",
        "as i said", "once again", "thanks for finally"
    ],
    "S7_Analytical": [
        "what's the data", "according to", "evidence", "metrics", "results show",
        "hypothesis", "let me think", "the reason is", "because", "therefore",
        "what's the roi", "cost-benefit", "breakdown", "analysis",
        "compared to", "statistically", "data shows", "numbers"
    ],
    "S8_Political": [
        "the ceo said", "leadership wants", "i ran it by",
        "make sure [vp]", "aligns with", "loop in", "visible on this",
        "senior leadership", "executive", "director wants",
        "stakeholders", "i mentioned this weeks ago", "my idea"
    ],
    "S9_Collaborative": [
        "what does everyone think", "team effort", "we did this together",
        "your input matters", "let's decide together", "open to ideas",
        "thoughts?", "building on what", "couldn't have done this without",
        "our approach", "together", "collectively", "as a team", "what do you think"
    ],
    "S10_Disengaged": [
        "ok", "sure", "sounds good", "k.", "yep", "will do",
        "on it", "got it", "noted", "fine", "okay", "👍", "ack",
        "alright", "mm", "yup"
    ]
}

RISK_THRESHOLDS = {
    "S3_Deflecting": 3,
    "S6_Passive_Aggressive": 2,
    "S8_Political": 3,
    "S10_Disengaged": 4
}


def classify_message(text: str) -> list[str]:
    """Return list of subaudition labels matched for a given message."""
    text_lower = text.lower()
    matched = []
    for label, keywords in SUBAUDITIONS.items():
        for kw in keywords:
            if kw.lower() in text_lower:
                matched.append(label)
                break  # one match per subaudition per message
    # Default: if no match and message is very short, lean S10
    if not matched and len(text.split()) <= 3:
        matched.append("S10_Disengaged")
    return matched if matched else ["Unclassified"]


def build_matrix(records: list[dict]) -> dict:
    """Build per-speaker subaudition frequency matrix."""
    all_labels = list(SUBAUDITIONS.keys()) + ["Unclassified"]
    matrix = defaultdict(lambda: defaultdict(int))
    message_log = []

    for rec in records:
        speaker = rec["speaker"]
        text = rec["text"]
        labels = classify_message(text)
        for label in labels:
            matrix[speaker][label] += 1
        message_log.append({
            "speaker": speaker,
            "index": rec.get("index", 0),
            "text": text,
            "subauditions": labels
        })

    return dict(matrix), message_log, all_labels


def detect_risks(matrix: dict) -> list[dict]:
    """Flag speakers who exceed risk thresholds."""
    risks = []
    for speaker, counts in matrix.items():
        total = sum(counts.values())
        for sub, threshold in RISK_THRESHOLDS.items():
            count = counts.get(sub, 0)
            if total > 0 and count >= threshold:
                risks.append({
                    "speaker": speaker,
                    "subaudition": sub,
                    "count": count,
                    "total_messages": total,
                    "percentage": round(count / total * 100, 1)
                })
    return risks


def main():
    parser = argparse.ArgumentParser(description="Classify subauditions — Cagey Project")
    parser.add_argument("--input", required=True, help="Path to parsed.json")
    parser.add_argument("--output", default="subaudition_matrix.csv")
    parser.add_argument("--log", default="classified_messages.json")
    parser.add_argument("--risks", default="risk_flags.json")
    args = parser.parse_args()

    with open(args.input, encoding='utf-8') as f:
        records = json.load(f)

    matrix, message_log, all_labels = build_matrix(records)
    risks = detect_risks(matrix)

    # Write matrix CSV
    speakers = sorted(matrix.keys())
    label_cols = list(SUBAUDITIONS.keys()) + ["Unclassified"]

    with open(args.output, 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow(["Speaker"] + label_cols + ["Total"])
        for sp in speakers:
            row = [sp] + [matrix[sp].get(lbl, 0) for lbl in label_cols]
            row.append(sum(matrix[sp].values()))
            writer.writerow(row)

    # Write classified messages
    with open(args.log, 'w', encoding='utf-8') as f:
        json.dump(message_log, f, indent=2, ensure_ascii=False)

    # Write risk flags
    with open(args.risks, 'w', encoding='utf-8') as f:
        json.dump(risks, f, indent=2, ensure_ascii=False)

    print(f"Matrix saved to: {args.output}")
    print(f"Message log saved to: {args.log}")
    print(f"Risk flags saved to: {args.risks}")
    print(f"\n=== SUBAUDITION MATRIX ===")
    print(f"{'Speaker':<20}", end="")
    for lbl in label_cols:
        short = lbl.split("_")[0]
        print(f"{short:>6}", end="")
    print(f"{'Total':>7}")
    for sp in speakers:
        print(f"{sp:<20}", end="")
        for lbl in label_cols:
            print(f"{matrix[sp].get(lbl, 0):>6}", end="")
        print(f"{sum(matrix[sp].values()):>7}")

    if risks:
        print(f"\n=== RISK FLAGS ===")
        for r in risks:
            print(f"  ⚠ {r['speaker']}: {r['subaudition']} — {r['count']} hits ({r['percentage']}%)")


if __name__ == "__main__":
    main()
