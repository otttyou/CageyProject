#!/usr/bin/env python3
"""Parse loose chat text into canonical message JSON.

Handles common formats:
  Alice [09:14]: text
  Alice — 09:14
  text
  [2026-03-12 14:22] Alice: text
  王雷 2026-03-12 14:22
  text

Usage:
  python parse_generic.py input.txt [--channel NAME] [--date 2026-03-12] > messages.json
"""
import argparse, json, re, sys
from datetime import datetime

PATTERNS = [
    # [2026-03-12 14:22] Alice: text
    re.compile(r'^\[(?P<ts>\d{4}-\d{2}-\d{2}[ T]\d{1,2}:\d{2}(?::\d{2})?)\]\s+(?P<speaker>[^:]+?):\s*(?P<text>.*)$'),
    # Alice [Mon 09:14]: text or Alice [09:14]: text
    re.compile(r'^(?P<speaker>[^\[]+?)\s*\[(?:(?P<dow>\w{3})\s+)?(?P<ts>\d{1,2}:\d{2}(?::\d{2})?)\]\s*:\s*(?P<text>.*)$'),
    # Alice 09:14 text  (inline)
    re.compile(r'^(?P<speaker>[^\d:]+?)\s+(?P<ts>\d{1,2}:\d{2}(?::\d{2})?)\s+(?P<text>.+)$'),
    # Alice: text  (no timestamp)
    re.compile(r'^(?P<speaker>[^:]{1,40}?):\s*(?P<text>.*)$'),
]

HEADER_ONLY = [
    # Alice — 09:14  (header line, text on next line)
    re.compile(r'^(?P<speaker>[^\d—\-]+?)\s*[—\-]\s*(?P<ts>\d{1,2}:\d{2}(?::\d{2})?)\s*$'),
    # 王雷 2026-03-12 14:22
    re.compile(r'^(?P<speaker>\S.+?)\s+(?P<ts>\d{4}-\d{2}-\d{2}\s+\d{1,2}:\d{2}(?::\d{2})?)\s*$'),
]


def normalize_ts(raw, default_date):
    if not raw:
        return None
    raw = raw.replace('T', ' ').strip()
    fmts = ['%Y-%m-%d %H:%M:%S', '%Y-%m-%d %H:%M', '%H:%M:%S', '%H:%M']
    for f in fmts:
        try:
            dt = datetime.strptime(raw, f)
            if f in ('%H:%M', '%H:%M:%S') and default_date:
                dt = datetime.combine(default_date, dt.time())
            return dt.isoformat()
        except ValueError:
            continue
    return raw


def parse_text(lines, channel=None, default_date=None):
    messages = []
    i = 0
    pending = None  # (speaker, ts) waiting for a text line
    while i < len(lines):
        line = lines[i].rstrip()
        if not line.strip():
            i += 1
            continue
        matched = False
        if pending:
            messages.append({
                'id': len(messages) + 1,
                'speaker': pending[0].strip(),
                'role': 'unknown',
                'ts': normalize_ts(pending[1], default_date),
                'channel': channel,
                'text': line.strip(),
            })
            pending = None
            i += 1
            continue
        for p in HEADER_ONLY:
            m = p.match(line)
            if m:
                pending = (m.group('speaker'), m.group('ts'))
                matched = True
                break
        if matched:
            i += 1
            continue
        for p in PATTERNS:
            m = p.match(line)
            if m:
                ts = m.groupdict().get('ts')
                messages.append({
                    'id': len(messages) + 1,
                    'speaker': m.group('speaker').strip(),
                    'role': 'unknown',
                    'ts': normalize_ts(ts, default_date) if ts else None,
                    'channel': channel,
                    'text': m.group('text').strip(),
                })
                matched = True
                break
        if not matched and messages:
            # treat as continuation of previous message
            messages[-1]['text'] += ' ' + line.strip()
        i += 1
    return messages


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('input')
    ap.add_argument('--channel', default=None)
    ap.add_argument('--date', default=None, help='Default date YYYY-MM-DD for timestamps without a date')
    ap.add_argument('-o', '--output', default='-')
    args = ap.parse_args()
    default_date = datetime.strptime(args.date, '%Y-%m-%d').date() if args.date else None
    with open(args.input, 'r', encoding='utf-8') as f:
        lines = f.readlines()
    messages = parse_text(lines, channel=args.channel, default_date=default_date)
    out = json.dumps(messages, indent=2, ensure_ascii=False)
    if args.output == '-':
        sys.stdout.write(out)
    else:
        with open(args.output, 'w', encoding='utf-8') as f:
            f.write(out)
    print(f"\nParsed {len(messages)} messages", file=sys.stderr)


if __name__ == '__main__':
    main()
