#!/usr/bin/env python3
"""
visualize.py — Cagey Project
Generate 4 visualizations of subaudition data:
  1. Stacked bar chart (by speaker)
  2. Heatmap (speaker × subaudition)
  3. Radar/spider chart (top speaker or specified speaker)
  4. Pie chart (overall subaudition distribution)

Usage:
    python visualize.py --matrix subaudition_matrix.csv --output-dir assets/
    python visualize.py --matrix subaudition_matrix.csv --radar-speaker "Boss" --output-dir assets/
"""

import argparse
import csv
import os
import math
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.cm as cm
from matplotlib.patches import FancyBboxPatch

# Color palette — professional, distinct
PALETTE = [
    "#4E79A7", "#F28E2B", "#E15759", "#76B7B2",
    "#59A14F", "#EDC948", "#B07AA1", "#FF9DA7",
    "#9C755F", "#BAB0AC", "#6E6E6E"
]

SUBAUDITION_SHORT = {
    "S1_Directive": "Directive",
    "S2_Approving": "Approving",
    "S3_Deflecting": "Deflecting",
    "S4_Micromanaging": "Micromanag.",
    "S5_Supportive": "Supportive",
    "S6_Passive_Aggressive": "Pass.-Aggr.",
    "S7_Analytical": "Analytical",
    "S8_Political": "Political",
    "S9_Collaborative": "Collaborat.",
    "S10_Disengaged": "Disengaged",
    "Unclassified": "Other"
}


def load_matrix(path: str):
    speakers, labels, data = [], [], {}
    with open(path, newline='', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        fieldnames = reader.fieldnames or []
        labels = [c for c in fieldnames if c not in ("Speaker", "Total")]
        for row in reader:
            sp = row["Speaker"]
            speakers.append(sp)
            data[sp] = {lbl: int(row.get(lbl, 0)) for lbl in labels}
    return speakers, labels, data


def stacked_bar(speakers, labels, data, output_dir):
    fig, ax = plt.subplots(figsize=(max(10, len(speakers) * 1.5), 7))
    fig.patch.set_facecolor('#1E1E2E')
    ax.set_facecolor('#1E1E2E')

    x = np.arange(len(speakers))
    bottoms = np.zeros(len(speakers))

    for i, lbl in enumerate(labels):
        vals = np.array([data[sp].get(lbl, 0) for sp in speakers], dtype=float)
        color = PALETTE[i % len(PALETTE)]
        short = SUBAUDITION_SHORT.get(lbl, lbl)
        ax.bar(x, vals, bottom=bottoms, color=color, label=short, edgecolor='#1E1E2E', linewidth=0.5)
        bottoms += vals

    ax.set_xticks(x)
    ax.set_xticklabels(speakers, rotation=30, ha='right', color='white', fontsize=10)
    ax.set_ylabel("Message Count", color='white', fontsize=11)
    ax.set_title("Cagey Project — Subaudition Distribution by Speaker",
                 color='white', fontsize=14, fontweight='bold', pad=15)
    ax.tick_params(colors='white')
    ax.spines['bottom'].set_color('#555')
    ax.spines['left'].set_color('#555')
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.yaxis.grid(True, color='#444', linestyle='--', alpha=0.5)
    ax.set_axisbelow(True)

    legend = ax.legend(loc='upper right', bbox_to_anchor=(1.18, 1),
                       fontsize=8, framealpha=0.3, labelcolor='white',
                       facecolor='#2A2A3E', edgecolor='#555')

    plt.tight_layout()
    out = os.path.join(output_dir, "stacked_bar.png")
    plt.savefig(out, dpi=150, bbox_inches='tight', facecolor=fig.get_facecolor())
    plt.close()
    print(f"Saved: {out}")


def heatmap(speakers, labels, data, output_dir):
    matrix = np.array([[data[sp].get(lbl, 0) for lbl in labels] for sp in speakers], dtype=float)
    short_labels = [SUBAUDITION_SHORT.get(l, l) for l in labels]

    fig, ax = plt.subplots(figsize=(max(12, len(labels) * 1.2), max(5, len(speakers) * 0.9)))
    fig.patch.set_facecolor('#1E1E2E')
    ax.set_facecolor('#1E1E2E')

    im = ax.imshow(matrix, cmap='YlOrRd', aspect='auto')

    ax.set_xticks(np.arange(len(short_labels)))
    ax.set_yticks(np.arange(len(speakers)))
    ax.set_xticklabels(short_labels, rotation=35, ha='right', color='white', fontsize=9)
    ax.set_yticklabels(speakers, color='white', fontsize=10)
    ax.tick_params(colors='white')

    for i in range(len(speakers)):
        for j in range(len(labels)):
            val = int(matrix[i, j])
            if val > 0:
                text_color = 'black' if matrix[i, j] > matrix.max() * 0.6 else 'white'
                ax.text(j, i, str(val), ha='center', va='center',
                        color=text_color, fontsize=9, fontweight='bold')

    cbar = fig.colorbar(im, ax=ax, shrink=0.8)
    cbar.ax.tick_params(colors='white')
    cbar.set_label('Frequency', color='white')

    ax.set_title("Cagey Project — Subaudition Frequency Heatmap",
                 color='white', fontsize=14, fontweight='bold', pad=15)

    plt.tight_layout()
    out = os.path.join(output_dir, "heatmap.png")
    plt.savefig(out, dpi=150, bbox_inches='tight', facecolor=fig.get_facecolor())
    plt.close()
    print(f"Saved: {out}")


def radar_chart(speakers, labels, data, output_dir, radar_speaker=None):
    # Choose speaker with most messages if not specified
    if radar_speaker is None:
        radar_speaker = max(speakers, key=lambda sp: sum(data[sp].values()))

    vals = [data[radar_speaker].get(lbl, 0) for lbl in labels]
    short_labels = [SUBAUDITION_SHORT.get(l, l) for l in labels]
    N = len(labels)
    angles = [n / float(N) * 2 * math.pi for n in range(N)]
    angles += angles[:1]
    vals_plot = vals + vals[:1]

    fig, ax = plt.subplots(figsize=(8, 8), subplot_kw=dict(polar=True))
    fig.patch.set_facecolor('#1E1E2E')
    ax.set_facecolor('#1E1E2E')

    ax.plot(angles, vals_plot, color='#4E79A7', linewidth=2)
    ax.fill(angles, vals_plot, color='#4E79A7', alpha=0.35)

    ax.set_xticks(angles[:-1])
    ax.set_xticklabels(short_labels, color='white', fontsize=9)
    ax.tick_params(colors='white')
    ax.yaxis.set_tick_params(labelcolor='#aaa')
    ax.spines['polar'].set_color('#555')
    ax.grid(color='#444', linestyle='--', alpha=0.6)

    ax.set_title(f"Cagey Project — Subaudition Profile: {radar_speaker}",
                 color='white', fontsize=13, fontweight='bold', pad=20)

    plt.tight_layout()
    out = os.path.join(output_dir, "radar_chart.png")
    plt.savefig(out, dpi=150, bbox_inches='tight', facecolor=fig.get_facecolor())
    plt.close()
    print(f"Saved: {out}")


def pie_chart(speakers, labels, data, output_dir):
    totals = {}
    for lbl in labels:
        totals[lbl] = sum(data[sp].get(lbl, 0) for sp in speakers)

    # Filter out zero-count categories
    non_zero = {k: v for k, v in totals.items() if v > 0}
    if not non_zero:
        print("No data for pie chart.")
        return

    pie_labels = [SUBAUDITION_SHORT.get(k, k) for k in non_zero]
    sizes = list(non_zero.values())
    colors = [PALETTE[i % len(PALETTE)] for i in range(len(pie_labels))]

    fig, ax = plt.subplots(figsize=(9, 8))
    fig.patch.set_facecolor('#1E1E2E')
    ax.set_facecolor('#1E1E2E')

    wedges, texts, autotexts = ax.pie(
        sizes, labels=pie_labels, colors=colors,
        autopct='%1.1f%%', startangle=140,
        textprops={'color': 'white', 'fontsize': 9},
        wedgeprops={'edgecolor': '#1E1E2E', 'linewidth': 1.5}
    )
    for at in autotexts:
        at.set_color('white')
        at.set_fontsize(8)

    ax.set_title("Cagey Project — Overall Subaudition Distribution",
                 color='white', fontsize=14, fontweight='bold', pad=15)

    plt.tight_layout()
    out = os.path.join(output_dir, "pie_chart.png")
    plt.savefig(out, dpi=150, bbox_inches='tight', facecolor=fig.get_facecolor())
    plt.close()
    print(f"Saved: {out}")


def main():
    parser = argparse.ArgumentParser(description="Visualize subauditions — Cagey Project")
    parser.add_argument("--matrix", required=True, help="Path to subaudition_matrix.csv")
    parser.add_argument("--output-dir", default="assets", help="Output directory for charts")
    parser.add_argument("--radar-speaker", default=None, help="Speaker name for radar chart")
    args = parser.parse_args()

    os.makedirs(args.output_dir, exist_ok=True)
    speakers, labels, data = load_matrix(args.matrix)

    if not speakers:
        print("No data found in matrix.")
        return

    print(f"Generating charts for {len(speakers)} speakers, {len(labels)} subauditions...")
    stacked_bar(speakers, labels, data, args.output_dir)
    heatmap(speakers, labels, data, args.output_dir)
    radar_chart(speakers, labels, data, args.output_dir, args.radar_speaker)
    pie_chart(speakers, labels, data, args.output_dir)
    print("All charts generated successfully.")


if __name__ == "__main__":
    main()
