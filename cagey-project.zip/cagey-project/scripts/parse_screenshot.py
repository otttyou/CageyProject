#!/usr/bin/env python3
"""OCR chat screenshots and feed the result through parse_generic.

Requires tesseract: apt-get install -y tesseract-ocr
Requires pytesseract and pillow: pip install pytesseract pillow --break-system-packages

Usage:
  python parse_screenshot.py shot1.png shot2.png > messages.json
"""
import argparse, json, sys, subprocess, os

def ocr_image(path):
    try:
        import pytesseract
        from PIL import Image
    except ImportError:
        print("Install pytesseract + pillow first.", file=sys.stderr)
        sys.exit(1)
    try:
        return pytesseract.image_to_string(Image.open(path), lang='eng+chi_sim')
    except pytesseract.pytesseract.TesseractNotFoundError:
        print("Tesseract not installed. Run: apt-get install -y tesseract-ocr", file=sys.stderr)
        sys.exit(1)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('images', nargs='+')
    ap.add_argument('--raw-only', action='store_true', help='Print cleaned OCR text, skip parse')
    ap.add_argument('-o', '--output', default='-')
    args = ap.parse_args()

    all_text = []
    for p in args.images:
        raw = ocr_image(p)
        # light cleanup: drop common chat chrome
        cleaned = []
        for line in raw.splitlines():
            s = line.strip()
            if not s:
                continue
            if s.lower() in {'reply', 'edited', 'reply...', 'seen', 'delivered'}:
                continue
            cleaned.append(s)
        all_text.append('\n'.join(cleaned))

    combined = '\n\n'.join(all_text)

    if args.raw_only:
        print(combined)
        return

    # Always show raw first so the operator can sanity-check OCR
    print("=== OCR extracted text — review this before scoring ===", file=sys.stderr)
    print(combined, file=sys.stderr)
    print("=== end ===", file=sys.stderr)

    # Route through parse_generic
    here = os.path.dirname(os.path.abspath(__file__))
    tmp = '/tmp/_cagey_ocr.txt'
    with open(tmp, 'w', encoding='utf-8') as f:
        f.write(combined)
    subprocess.run(['python3', os.path.join(here, 'parse_generic.py'), tmp,
                    '-o', args.output if args.output != '-' else '/dev/stdout'])


if __name__ == '__main__':
    main()
