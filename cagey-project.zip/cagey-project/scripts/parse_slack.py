#!/usr/bin/env python3
"""Parse a Slack export (folder or single JSON/CSV) into canonical messages.

Usage:
  python parse_slack.py path/to/export_folder > messages.json
  python parse_slack.py channel.json > messages.json
  python parse_slack.py messages.csv > messages.json
"""
import argparse, csv, json, os, sys
from datetime import datetime


def load_users(folder):
    users_path = os.path.join(folder, 'users.json')
    if not os.path.exists(users_path):
        return {}
    with open(users_path, 'r', encoding='utf-8') as f:
        users = json.load(f)
    return {u['id']: u.get('real_name') or u.get('name') or u['id'] for u in users}


def from_slack_json(path, users, channel_name):
    with open(path, 'r', encoding='utf-8') as f:
        raw = json.load(f)
    out = []
    for m in raw:
        if m.get('subtype') == 'bot_message':
            continue
        if 'text' not in m:
            continue
        ts = m.get('ts')
        try:
            iso = datetime.fromtimestamp(float(ts)).isoformat() if ts else None
        except Exception:
            iso = None
        out.append({
            'speaker': users.get(m.get('user', ''), m.get('user', 'unknown')),
            'role': 'unknown',
            'ts': iso,
            'channel': channel_name,
            'text': m.get('text', ''),
            'reply_to': m.get('thread_ts'),
            'reactions': [r.get('name') for r in m.get('reactions', [])],
            'edited': bool(m.get('edited')),
        })
    return out


def from_csv(path):
    out = []
    with open(path, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        cols = {c.lower(): c for c in reader.fieldnames or []}
        speaker_col = next((cols[k] for k in ('user', 'username', 'from', 'sender', 'speaker') if k in cols), None)
        ts_col = next((cols[k] for k in ('timestamp', 'ts', 'time', 'date') if k in cols), None)
        text_col = next((cols[k] for k in ('message', 'text', 'body', 'content') if k in cols), None)
        channel_col = next((cols[k] for k in ('channel', 'room') if k in cols), None)
        for row in reader:
            out.append({
                'speaker': row.get(speaker_col, 'unknown') if speaker_col else 'unknown',
                'role': 'unknown',
                'ts': row.get(ts_col) if ts_col else None,
                'channel': row.get(channel_col) if channel_col else None,
                'text': row.get(text_col, '') if text_col else '',
            })
    return out


def walk_export(folder):
    users = load_users(folder)
    out = []
    for root, _, files in os.walk(folder):
        channel = os.path.basename(root)
        if channel == os.path.basename(folder):
            continue
        for fn in sorted(files):
            if fn.endswith('.json'):
                out.extend(from_slack_json(os.path.join(root, fn), users, channel))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('path')
    ap.add_argument('-o', '--output', default='-')
    args = ap.parse_args()
    if os.path.isdir(args.path):
        msgs = walk_export(args.path)
    elif args.path.endswith('.json'):
        msgs = from_slack_json(args.path, {}, os.path.splitext(os.path.basename(args.path))[0])
    else:
        msgs = from_csv(args.path)
    for i, m in enumerate(msgs, 1):
        m['id'] = i
    text = json.dumps(msgs, indent=2, ensure_ascii=False)
    if args.output == '-':
        sys.stdout.write(text)
    else:
        open(args.output, 'w', encoding='utf-8').write(text)
    print(f"\nParsed {len(msgs)} messages", file=sys.stderr)


if __name__ == '__main__':
    main()
