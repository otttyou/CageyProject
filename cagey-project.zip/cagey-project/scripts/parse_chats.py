#!/usr/bin/env python3
"""
parse_chats.py — Cagey Project
Parse raw chat input into structured records: [{speaker, index, text}]

Usage:
    python parse_chats.py --input <path> --format <auto|slack|whatsapp|csv|plain> --output parsed.json
"""

import argparse
import json
import re
import csv
import sys
from pathlib import Path


def parse_plain(text: str) -> list[dict]:
    """Parse plain text in 'Speaker: message' format."""
    records = []
    idx = 0
    for line in text.strip().splitlines():
        line = line.strip()
        if not line:
            continue
        match = re.match(r'^([^:]{1,40}):\s+(.+)$', line)
        if match:
            records.append({
                "speaker": match.group(1).strip(),
                "index": idx,
                "timestamp": None,
                "text": match.group(2).strip()
            })
            idx += 1
        else:
            # Continuation of previous message
            if records:
                records[-1]["text"] += " " + line
    return records


def parse_whatsapp(text: str) -> list[dict]:
    """Parse WhatsApp export format: DD/MM/YYYY, HH:MM - Speaker: message"""
    records = []
    idx = 0
    pattern = re.compile(
        r'(\d{1,2}/\d{1,2}/\d{2,4}),\s+(\d{1,2}:\d{2}(?:\s?[AP]M)?)\s+-\s+([^:]+):\s+(.+)'
    )
    for line in text.strip().splitlines():
        line = line.strip()
        m = pattern.match(line)
        if m:
            records.append({
                "speaker": m.group(3).strip(),
                "index": idx,
                "timestamp": f"{m.group(1)} {m.group(2)}",
                "text": m.group(4).strip()
            })
            idx += 1
        elif records and not line.startswith(('[')):
            records[-1]["text"] += " " + line
    return records


def parse_slack_json(data: list) -> list[dict]:
    """Parse Slack JSON export format."""
    records = []
    for idx, msg in enumerate(data):
        if isinstance(msg, dict) and "text" in msg:
            speaker = msg.get("user_profile", {}).get("display_name") or \
                      msg.get("username") or \
                      msg.get("user", f"user_{idx}")
            records.append({
                "speaker": speaker,
                "index": idx,
                "timestamp": msg.get("ts"),
                "text": msg.get("text", "").strip()
            })
    return records


def parse_csv_file(path: str) -> list[dict]:
    """Parse CSV with columns: speaker, message (and optionally timestamp)."""
    records = []
    with open(path, newline='', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for idx, row in enumerate(reader):
            speaker = row.get("speaker") or row.get("name") or row.get("user") or f"Person_{idx}"
            text = row.get("message") or row.get("text") or row.get("content") or ""
            ts = row.get("timestamp") or row.get("time") or row.get("date") or None
            if text.strip():
                records.append({
                    "speaker": speaker.strip(),
                    "index": idx,
                    "timestamp": ts,
                    "text": text.strip()
                })
    return records


def auto_detect_and_parse(path: str) -> list[dict]:
    """Auto-detect format and parse."""
    p = Path(path)
    if p.suffix == ".json":
        with open(path, encoding='utf-8') as f:
            data = json.load(f)
        return parse_slack_json(data)
    elif p.suffix == ".csv":
        return parse_csv_file(path)
    else:
        with open(path, encoding='utf-8') as f:
            text = f.read()
        # Try WhatsApp pattern first
        if re.search(r'\d{1,2}/\d{1,2}/\d{2,4},\s+\d{1,2}:\d{2}', text):
            return parse_whatsapp(text)
        else:
            return parse_plain(text)


def main():
    parser = argparse.ArgumentParser(description="Parse work chats for Cagey Project")
    parser.add_argument("--input", required=True, help="Path to input chat file")
    parser.add_argument("--format", default="auto",
                        choices=["auto", "slack", "whatsapp", "csv", "plain"])
    parser.add_argument("--output", default="parsed.json", help="Output JSON path")
    args = parser.parse_args()

    fmt = args.format
    if fmt == "auto":
        records = auto_detect_and_parse(args.input)
    elif fmt == "slack":
        with open(args.input, encoding='utf-8') as f:
            data = json.load(f)
        records = parse_slack_json(data)
    elif fmt == "whatsapp":
        with open(args.input, encoding='utf-8') as f:
            text = f.read()
        records = parse_whatsapp(text)
    elif fmt == "csv":
        records = parse_csv_file(args.input)
    elif fmt == "plain":
        with open(args.input, encoding='utf-8') as f:
            text = f.read()
        records = parse_plain(text)

    with open(args.output, 'w', encoding='utf-8') as f:
        json.dump(records, f, indent=2, ensure_ascii=False)

    print(f"Parsed {len(records)} messages from {len(set(r['speaker'] for r in records))} speakers.")
    print(f"Output saved to: {args.output}")


if __name__ == "__main__":
    main()
