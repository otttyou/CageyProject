# Cagey Project

A Claude skill for analyzing work chat logs between you, your colleagues, and your bosses — and surfacing the **subauditions**: the stress, frustration, morale shifts, warmth, and psychological-safety signals that live underneath the literal text.

## What it does

Reads chat transcripts (Slack exports, Teams/WeChat/generic pasted text, screenshots), scores every message along six emotional-undercurrent dimensions, sorts and rolls them up per speaker, per week, and per channel, then produces **three deliverables**:

1. **Interactive HTML dashboard** — self-contained, no build step, per-speaker cards, time-series, filterable top-cagey table
2. **Static charts + written report** — PNG charts plus a markdown report with quoted evidence
3. **Excel workbook** — scored messages with conditional formatting, plus by-speaker, by-week, top-cagey, risk-flag, and rubric sheets

It also scans for **risk-flag patterns** — sustained hostility, exclusion signals, panic spirals, psychological-safety erosion, sudden warmth reversals — and surfaces them observationally, without giving advice.

## Ethics

The skill is analytical and flag-based, not advisory. It never tells you how to reply, who to trust, or how to manage relationships. All readings are interpretations of tone, not claims about intent or mental state. It will decline to produce "case-building" content for HR or legal use and instead offer the neutral analytical outputs.

## Structure

```
cagey-project/
├── SKILL.md
├── README.md
├── references/
│   ├── intake.md       — input formats & edge cases
│   ├── rubric.md       — six-dimension scoring rubric with worked examples
│   ├── dashboard.md    — HTML dashboard structure and styling
│   ├── risk_flags.md   — pattern library for Phase 5
│   └── examples.md     — three fully worked mini-analyses
└── scripts/
    ├── parse_generic.py     — plain text / Teams / WeChat → canonical messages
    ├── parse_slack.py       — Slack JSON/CSV → canonical messages
    ├── parse_screenshot.py  — OCR screenshots → canonical messages
    ├── aggregate.py         — scored.json → rollups.json
    ├── build_dashboard.py   — rollups → self-contained HTML dashboard
    ├── build_report.py      — rollups → PNG charts + markdown report
    └── build_workbook.py    — rollups → xlsx with conditional formatting
```

## Installation

Drop this folder into your Claude skills directory (`.claude/skills/` in Cowork or Claude Code). Claude will auto-load it when you mention work chat analysis, "read between the lines," team morale, or similar phrases.

## Dependencies

- Python 3.9+
- `openpyxl` for the xlsx builder
- `matplotlib` for static charts
- `pytesseract` + `pillow` + system `tesseract-ocr` for screenshot OCR

Install with:

```bash
pip install openpyxl matplotlib pytesseract pillow --break-system-packages
apt-get install -y tesseract-ocr   # for screenshots
```

## License

MIT.
