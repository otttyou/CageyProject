---
name: cagey-project
description: Analyze work chat logs from colleagues and bosses to surface emotional undercurrents ("subauditions") — the stress, frustration, morale shifts, psychological safety signals, and relationship health cues lurking beneath literal text. Use this skill whenever the user wants to understand "what's really going on" in team chats, decode a boss's tone, track team morale over time, spot burnout or hostility before it escalates, or produce a visual readout of workplace emotional dynamics from Slack, Teams, WeChat, pasted transcripts, JSON/CSV exports, or even screenshots of conversations. Triggers on phrases like "read between the lines", "what does my boss really mean", "analyze our team chats", "is my manager frustrated with me", "team morale check", "subtext analysis", "cagey project", "workplace sentiment", or any request to sort, score, or visualize emotional subtext in work messages. The skill always produces three outputs: an interactive HTML dashboard, static charts plus a written report, and an XLSX workbook with scored rows — and it flags risks without giving relationship advice.
---

# Cagey Project — Workplace Chat Subaudition Analyzer

## What this skill does

"Subauditions" are the things people *almost* say — the feelings underneath the words. Work chats are full of them: the boss who says "interesting" when they mean "I disagree," the colleague whose "sure!" hides resentment, the team lead whose shrinking message length signals stress. This skill reads chat transcripts between the user and their colleagues or bosses, scores the emotional undercurrents, sorts them by intensity and type, and produces three visual deliverables plus risk flags.

The skill is **analytical and flag-based**, not advisory. It does not tell the user how to reply, who to trust, or how to manage relationships. It observes and visualizes. When it sees concerning patterns — sustained hostility, exclusion, panic spirals, psychological-safety erosion — it raises a flag and describes the pattern. The user decides what to do.

## When to use this skill

Trigger this skill whenever the user:

- Shares or references a chat log, Slack export, Teams thread, WeChat conversation, screenshot, or pasted transcript involving coworkers or managers and asks about tone, mood, or meaning
- Says things like "what's going on with my team," "read between the lines," "is my boss mad," "analyze our standup chat," "team vibe check," "morale report," "sort these messages by stress," "cagey project," or "subauditions"
- Wants to track emotional shifts across time, people, or channels
- Asks for a visualization, dashboard, spreadsheet, or report about workplace chat dynamics

Do **not** use this skill for brand voice work, for customer-support sentiment at scale, or for analyzing the user's *own* writing style — those have other skills.

## The workflow

Work through these phases in order. Each phase has a corresponding reference file — read it when you enter the phase, not upfront.

### Phase 1: Intake and parse

Figure out what the user has and normalize it into a single canonical format.

Accepted inputs (handle each):

- **Pasted text** or `.txt` file — loose transcripts, often copy-pasted from a chat app. Use `scripts/parse_generic.py` to extract speaker, timestamp, and message.
- **Slack exports** — JSON (per-channel `.json` files) or CSV. Use `scripts/parse_slack.py`.
- **Teams / WeChat / generic labeled chat** — lines like `Alice [09:14]: text` or `王雷 2026-03-12 14:22 — text`. Use `scripts/parse_generic.py`, which handles multiple date/time and name conventions.
- **Screenshots** of chat apps — run `scripts/parse_screenshot.py`, which uses Tesseract OCR (install with `apt-get install -y tesseract-ocr` if missing) to extract text, then feeds it back through the generic parser. Always visually inspect the output — OCR gets names and timestamps wrong.

All parsers emit a canonical JSON list of messages:

```json
[
  {"id": 1, "speaker": "Alice", "role": "boss", "ts": "2026-03-12T14:22:00", "channel": "#eng-standup", "text": "..."}
]
```

Before scoring, confirm with the user:

- Who in the log is the **user**? (exclude them from subject-of-analysis by default, but keep their messages for context)
- Which participants are **bosses/managers** vs. **peers**? Role tagging shapes the dashboard groupings.
- What time window matters most?

See `references/intake.md` for format specifics, edge cases (threaded replies, emoji reactions, edited messages, deleted messages, bots), and confirmation prompts.

### Phase 2: Score the subauditions

For each message, assign scores along the emotional-undercurrent dimensions defined in `references/rubric.md`. Read that file in full before scoring. Briefly, the dimensions are:

- **Stress / pressure** (0–5) — urgency, compressed timelines, venting
- **Frustration / suppressed anger** (0–5) — curtness, passive aggression, pointed "thanks"
- **Warmth / connection** (0–5) — humor, personal asks, genuine appreciation
- **Psychological safety** (0–5) — willingness to say "I don't know," disagree, joke
- **Withdrawal / disengagement** (0–5) — shrinking responses, silence, flat affect
- **Morale drift** (−5 to +5) — relative change vs. that speaker's baseline

Each message also gets:

- A **dominant undercurrent label** (one short phrase like "quiet resentment," "burned out but coping," "relieved," "performative enthusiasm")
- A **confidence score** (0–1) — how sure the reading is given available context
- A **quoted evidence span** — the specific words that drove the reading

Scoring is context-dependent. A single "ok." reads very differently after a string of enthusiastic messages vs. after an argument. Always consider the 3–5 messages of surrounding context and the speaker's own baseline tone.

Never fabricate evidence. If the context is too thin, assign low confidence and say so rather than guessing.

### Phase 3: Sort and aggregate

Once every message is scored, sort and roll up using `scripts/aggregate.py`:

- **Per speaker**: mean and trajectory for each dimension, sparkline over time, top 5 highest-intensity messages, top 5 lowest-confidence readings (so the user can sanity-check).
- **Per channel**: same rollups scoped to channel.
- **Per week**: time series of each dimension, computed as a rolling average to smooth out single-message spikes.
- **Most-cagey messages**: a sorted list of the top N (default 25) messages with the strongest subtext-vs-surface gap — i.e., where the literal text looks neutral but the undercurrent score is high. These are the headline rows.

### Phase 4: Visualize (three deliverables, always)

Always produce all three of the following. Do not ask the user which they want — the brief is "all three formats."

1. **Interactive HTML dashboard** — `scripts/build_dashboard.py` generates a single self-contained `cagey_dashboard.html` with: per-person cards, time-series charts of each dimension, a filterable sortable message table, a heatmap of tension-by-person-by-week, and risk flag callouts. Uses vanilla JS + inline Chart.js from CDN; no build step. See `references/dashboard.md` for the structure and styling conventions.

2. **Static charts + written report** — `scripts/build_report.py` saves PNG charts (matplotlib) into `charts/` and writes a `cagey_report.md` (or `.docx` if the docx skill is available and the user prefers) covering: executive summary, per-person sections with sparklines, the top cagey messages with quoted evidence, trend commentary, and a risk-flag section. The report uses plain observational language — "messages from X showed shorter average length and fewer questions in the second half of the window" — not diagnoses.

3. **Spreadsheet** — `scripts/build_workbook.py` produces `cagey_scores.xlsx` with sheets: `Messages` (every scored row with evidence and confidence), `By Speaker`, `By Week`, `Top Cagey`, `Risk Flags`, and `Rubric` (the scoring definitions, so the user can audit). Conditional formatting color-scales each dimension column. Follow the xlsx skill conventions if available.

All three outputs read from the same intermediate `scored.json` file, so scoring only happens once.

### Phase 5: Risk flags

After aggregation, scan for the patterns defined in `references/risk_flags.md`. The goal is to surface concerning dynamics without telling the user what to do about them. Examples:

- **Sustained hostility pattern** — one speaker directs elevated frustration at another across multiple days
- **Exclusion signal** — a participant's share of messages drops sharply while the channel remains active
- **Panic spiral** — stress scores across the whole channel climb together in a short window
- **Psychological-safety erosion** — questions and disagreement vanish; messages become shorter and more uniform
- **Sudden warmth reversal** — a previously warm speaker goes flat or curt

Each flag gets: a name, the time window, the people involved, the evidence (quoted messages), and a neutral one-line description. Flags appear in all three deliverables. The skill never advises the user to quit, confront someone, or report anything — it only names the pattern.

## Deliver

After the three files are built, save them into the user's selected folder and present all three with computer:// links. Include a one-paragraph summary that names: the time window, number of messages, number of participants, the top 2–3 observed patterns, and any risk flags raised. Be matter-of-fact; avoid drama.

## Ethical ground rules

This skill analyzes private communications. Before scoring, remind the user once that the readings are interpretations, not facts, and that the skill cannot know intent. Do not export names, IDs, or evidence spans anywhere outside the user's selected folder. Do not speculate about mental health diagnoses. Do not produce content that could be used to retaliate against or publicly shame a named individual.

If the user asks the skill to "build a case against" someone or to produce content for an HR complaint or legal action, decline the framing and instead offer the neutral analytical outputs — let the user draw their own conclusions from the evidence.

## Reference files

Read these when you reach the relevant phase:

- `references/intake.md` — input formats, edge cases, confirmation prompts
- `references/rubric.md` — scoring dimensions with worked examples
- `references/dashboard.md` — HTML dashboard structure and styling
- `references/risk_flags.md` — the pattern library for Phase 5
- `references/examples.md` — three fully worked mini-analyses

## Scripts

- `scripts/parse_slack.py` — Slack JSON/CSV → canonical messages
- `scripts/parse_generic.py` — plain text / Teams / WeChat → canonical messages
- `scripts/parse_screenshot.py` — screenshot OCR → canonical messages
- `scripts/aggregate.py` — scored.json → rollups (per speaker, week, channel, top-cagey)
- `scripts/build_dashboard.py` — rollups → `cagey_dashboard.html`
- `scripts/build_report.py` — rollups → PNG charts + `cagey_report.md`
- `scripts/build_workbook.py` — rollups → `cagey_scores.xlsx`
