---
name: cagey-project
description: >
  Cagey Project: Analyze colleagues' and bosses' work chat messages to uncover
  communication patterns, sentiment, dominance dynamics, and behavioral subauditions
  (subcategories of communication styles and interaction tendencies). Extracts, classifies,
  and visualizes chat data. Use when asked to analyze work chats, boss/colleague messages,
  office communication, Slack/Teams/email threads, behavioral profiling of coworkers,
  sorting subauditions, or visualizing communication patterns from workplace chats.
license: MIT
metadata:
  author: cagey-project
  version: '1.0'
  project: Cagey Project
---

# Cagey Project

**Analyzing colleagues and bosses' work chats — sorting and visualizing subauditions.**

## When to Use This Skill

Load this skill when the user wants to:

- Analyze work chat messages from colleagues or bosses (Slack, Teams, email, WhatsApp, etc.)
- Detect communication subauditions (sub-patterns, behavioral tendencies) in chat logs
- Sort and rank individuals by subaudition categories
- Visualize communication dynamics with charts and graphs
- Profile a colleague or boss's communication style from their messages
- Identify dominant, passive, manipulative, supportive, or other behavioral signals

---

## Core Concepts

### What Is a Subaudition?

A **subaudition** is an implicit meaning, behavioral tendency, or communication sub-pattern
embedded within messages — things not directly stated but consistently exhibited. In workplace
chat analysis, subauditions are clustered behavioral signals such as:

| Subaudition ID | Label | Description |
|---|---|---|
| S1 | **Directive** | Commands, assigns tasks, sets deadlines |
| S2 | **Approving** | Validates others' ideas, praises, affirms |
| S3 | **Deflecting** | Avoids responsibility, redirects blame |
| S4 | **Micromanaging** | Excessive follow-up, over-specification |
| S5 | **Supportive** | Offers help, emotional support, encouragement |
| S6 | **Passive-Aggressive** | Indirect criticism, sarcasm, backhanded compliments |
| S7 | **Analytical** | Asks for data, reasons thoroughly, challenges assumptions |
| S8 | **Political** | Name-drops, aligns with power, manages perception |
| S9 | **Collaborative** | Invites input, shares credit, uses "we" language |
| S10 | **Disengaged** | Minimal responses, late replies, vague answers |

---

## Workflow

### Phase 1 — Ingest Chat Data

1. Accept chat data from the user in any of these formats:
   - Pasted raw text (Slack export, Teams copy-paste, WhatsApp export)
   - Uploaded `.txt`, `.csv`, `.json`, or `.xlsx` file
   - Description of messages (user summarizes key messages)

2. Parse each message into a structured record:
   ```
   { speaker, timestamp (if available), message_text }
   ```

3. If no timestamps are available, assign sequential indices.

4. Group messages by **speaker** (each unique person = one profile).

### Phase 2 — Subaudition Classification

For each message, score it against the 10 subaudition categories (S1–S10):

- Use the reference guide in `references/subaudition-rules.md` for keyword triggers and linguistic patterns.
- Assign **one primary subaudition** and optionally **one secondary subaudition** per message.
- Build a **subaudition frequency matrix** per speaker:
  ```
  Speaker | S1 | S2 | S3 | S4 | S5 | S6 | S7 | S8 | S9 | S10 | Total
  ```

### Phase 3 — Sort Subauditions

Sort results in these ordered views:
1. **By speaker**: Who exhibits which subauditions most?
2. **By subaudition**: Which subaudition is most common across all speakers?
3. **Top-3 subaudition profile per person**: Each individual's dominant communication fingerprint.
4. **Risk flags**: Any speaker with high S3 (Deflecting), S6 (Passive-Aggressive), or S8 (Political) scores.

### Phase 4 — Visualize

Generate visualizations using the `scripts/visualize.py` script. Produce:

1. **Stacked Bar Chart** — Each speaker as a bar, colored segments per subaudition
2. **Heatmap** — Speaker × Subaudition frequency matrix
3. **Radar/Spider Chart** — Per-person subaudition fingerprint (top speaker or selected speaker)
4. **Pie Chart** — Overall distribution of subauditions across all messages

Save all charts to `assets/` as `.png` files.

### Phase 5 — Report

After generating visuals, produce a written summary including:

- **Overall team communication climate** (1 paragraph)
- **Individual profiles** (2–3 sentences per person): dominant subauditions and what they signal
- **Risk alerts**: flag any patterns suggesting conflict, disengagement, or political maneuvering
- **Recommendations**: how to engage each person more effectively

---

## Step-by-Step Instructions

1. **Receive data**: Ask user to paste or upload their chat logs if not provided.
2. **Parse**: Use `scripts/parse_chats.py` to structure the data. If data is pasted text, write it to a temp file first.
3. **Classify**: Run `scripts/classify_subauditions.py` over the parsed data.
4. **Sort**: Produce sorted tables (by speaker, by subaudition, risk flags).
5. **Visualize**: Run `scripts/visualize.py` to generate all 4 chart types.
6. **Share charts**: Call `share_file` for each chart.
7. **Write report**: Produce the written summary as a markdown document.
8. **Optionally save**: Offer to save as PDF or DOCX if user requests.

---

## Input Formats Supported

| Format | Handling |
|---|---|
| Raw pasted text | Extract `Speaker: message` lines with regex |
| Slack JSON export | Parse `user`, `text`, `ts` fields |
| WhatsApp `.txt` | Parse `DD/MM/YYYY, HH:MM - Name: message` lines |
| CSV with columns `speaker, message` | Direct pandas ingest |
| Free-form description | Agent interprets and assigns messages manually |

---

## Output Artifacts

- `assets/stacked_bar.png` — Stacked bar chart by speaker
- `assets/heatmap.png` — Subaudition frequency heatmap
- `assets/radar_chart.png` — Radar chart for top speaker
- `assets/pie_chart.png` — Overall subaudition distribution
- `assets/subaudition_matrix.csv` — Full frequency matrix
- Written markdown summary report

---

## Example Usage

> **User**: "Here are some Slack messages from my team. My boss always says things like 'just make sure it's done by EOD' and my colleague keeps saying 'that's not my area'. Can you analyze them?"

**Agent steps**:
1. Parse the messages, assign speakers (Boss, Colleague, etc.)
2. Classify: Boss → S1 (Directive) + S4 (Micromanaging); Colleague → S3 (Deflecting)
3. Build frequency matrix
4. Generate stacked bar + heatmap + radar + pie charts
5. Share charts and write profile report

---

## Notes

- Never store or transmit chat data externally — all processing is local within the workspace.
- Be sensitive: the goal is professional insight, not to embarrass or harm colleagues.
- If a speaker has fewer than 3 messages, note that the profile has low confidence.
- Subaudition classification is probabilistic — present findings as tendencies, not definitive judgments.
